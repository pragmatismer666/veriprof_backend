<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Professional extends CI_Controller
{

    private static $instance = null;

    function __construct()
    {
        parent::__construct();
        $this->load->model('profile_model');
        $this->load->model('project_model');
        $this->load->model('plan_model');
        $this->load->model('business_model');
        $this->load->model('report_model');
        $this->load->model('verify_model');
        $this->load->model('support_model');
    }

    static public function getInstance() {

        if (self::$instance == null)
        {
            self::$instance = new Professional();
        }
    
        return self::$instance;
    }

    public function response($data) {
        echo json_encode($data);
        return;
    }

    public function jsonInput() {
        $json = file_get_contents('php://input');
        return json_decode($json, true);
    }
   
    public function addProfile() {
        $data = $this->jsonInput();
        if ($data == null){
            return null;
        }
        $input = $data['data'];
        $input['user_id'] = $data['user_id'];
        $input['updated_at'] = date('Y-m-d h:i:s');
        $result = $this->profile_model->addNew($input);
        if($result == 'error') { return $this->response(['status' => 'error','result'=>"false", 'message' => 'Insert Error']); }
        else if ($result == "update"){ return $this->response(['status' => 'success','result'=>$result, 'message' => 'Successfully Update, Already Registered']);}
        else{
            return $this->response(['status' => 'success','result' => $result,'message' => 'Profile Updated, please check email for verification.']);
            // $send_email = $data['send_mail'];
            // $check_values['name'] = $data['user_name'];
            // $check_values['verify_id'] = $data['check_id'];
            // $check_values['reg_id'] = $data['reg_id'];
            // $check_result = $this->verify_model->checkUser($check_values);
            // if ($check_result == "true") {           
            //     $verification_code = $this->getVerifyCode(); 
            //     $verified = "Your ID is verified ID.  The Verification Code is : ".$verification_code;
            //     $this->sendEmail($send_email,$verified);
            //     $verify_message = 'Your ID is ID is validate, Profile Created please check email for verification.';
            //     $reg_num['reg_number'] = $data['reg_id'];
            //     $this->profile_model->registerProfile($reg_num,$data['user_id']);
            // }
            // else{
            //     $verify_message = 'Profile Created please check email for verification.';
            //     $email_message = 'Thank you '.$data['user_name'].' for creating your VeriProd profile. 
            //     Your details has been sent to the various  governing bodies for further verification. 
            //     In the next 24hours, you will get an update about your profile...';
            //     $this->sendEmail($send_email,$email_message);
            // }  
            // return $this->response(['status' => 'success','file' => $input['file'],'message' => $verify_message]);             
        }            
    }

    public function getProfile() {
        $data             = $this->jsonInput();
        $objs = $this->profile_model->getByUserId($data);
        if ( $objs == false ){ return $this->response(['status' =>'noexist', 'personal'=>$objs]); }
        else { return $this->response(['status' =>'success', 'personal'=>$objs[0]]); }
    }

    public function updatePay(){
        $data             = $this->jsonInput();        
        $input['account'] = $data['account'];
        $input['account_updated'] = date('Y-m-d');
        $this->profile_model->updateProfile($input,$data['user_id']);
        $created_by['created_by'] = $data['user_id'];
        $objs = $this->profile_model->getByCreatedBy($created_by);
        return $this->response(['status' =>'success', 'personal'=>$objs]);
    }

    public function checkRegister() {
        $data             = $this->jsonInput();
        $objs = $this->profile_model->checkProfessRegister($data['user_id']);
        return $this->response(['status' => 'success', 'data' => $objs,'message'=>'Successfully']);
    }

    public function getProfess() {
        $result = $this->profile_model->getallProfiles();
        return $this->response(['status' => 'success', 'data' => $result, 'message'=>'Successfully']);
    }

    public function addProject() {
        $data             = $this->jsonInput();
        $input            = $data['data'];
        $input['created_by'] = $data['user_id'];
        $input['completed_at'] = "";
        
        $id = $this->project_model->addNew($input);
        if($id == false) { return $this->response(['status' => 'error', 'message' => 'Insert Error']); }
        else if ( $id == "exist" ) { return $this->response(['status' => 'success', 'id' => $id, 'message' => 'Project Name and Type is same with Old project.']);}
        return $this->response(['status' => 'success', 'id' => $id, 'message' => 'Successfully Inserted']);
    }

    public function getProject() {
        $data             = $this->jsonInput();
        $input['created_by'] = $data['user_id'];
        $objs = $this->project_model->getByCreatedBy($input);
        return $this->response(['status' => 'success', 'data' => $objs]);
    }
    
    public function actionProject() {
        $data = $this->jsonInput();
        $objs = $this->project_model->changeProjectstatus($data['title'], $data['user_id'], $data['verified']);
        return $this->response(['status' => 'success', 'data' => $objs]);
    }
//  ========================================================================================= Eplan Part ==================
    public function addPlan() {
        $data             = $this->jsonInput();
        if ($data == null){ return null; }
        $input            = $data['data'];
        $verification_code = $this->getVerifyCode();
        $result =  $this->createPdf($input);
        if ($result==false){return $this->response(['status' => 'error', 'message' => 'Insert Error']);}
        $input['verify_code'] = $verification_code;
        $input['created_by'] = $data['user_id'];
        $input['created_at'] = date('Y-m-d h:i:s');
        $input['certificate'] = $result;
        $id = $this->plan_model->addNew($input);
        if ($id == false)  { return $this->response(['status' => 'error', 'message' => 'Insert Error']); }
        else{
            $email_text = 'Your plan is submitted as successefully, Submission Confirmation Code is '.$verification_code;
            $this->sendEmail($input['contact_email'], $email_text);
            return $this->response(['status' => 'success', 'message' => 'Successfully Inserted']);
        }
    }

    public function getPlan() {
        $data = $this->jsonInput();
        $objs = $this->plan_model->getplans($data['user_id']);
        return $this->response(['status' => 'success', 'data' => $objs]);
    }

//  ========================================================================================== Business Part =================
    public function addBusiness() {
        $data  = $this->jsonInput(); 
        $input = $data['data']; 
        $head = $data['hoffice'];
        $branchs = $data['branchs']; 
        $staffs = $data["staffs"]; 
        $softs = $data["softs"]; 
        $hards = $data["hards"];
        $input['created_by'] = $data['user_id'];
        $input['updated_at'] = date('Y-m-d h:i:s');
        $id = $this->business_model->addNew($input);
        if($id == false) { return $this->response(['status' => 'error', 'id'=>$id, 'message' => 'Insert Error']); } 
        else {
            $result2 = true; $result3 = true;
            if ( sizeof($softs) > 0){ $result2 = $this->support_model->addEquip($softs, $id, $data['user_id'], 'soft'); }
            if ( sizeof($softs) > 0){ $result2 = $result3 = $this->support_model->addEquip($hards, $id, $data['user_id'], 'hard'); }
            if ( $result2 == false || $result3 == false){ return $this->response(['status' => 'error','id'=>'equipment', 'message' => 'Insert Error, Don`t saved anything']); }
            $result0 = $this->support_model->addOffice($head, $branchs, $id, $data['user_id']);
            if ( $result0 == false ){ return $this->response(['status' => 'error','id'=>'office', 'message' => 'Insert Error, Saved only Equipment']); }
            $this->profile_model->updateProfile(array('buzi_id'=>$id, 'office_id'=>$result0), $data['user_id'] );
            $result1 = true;
            if ( sizeof($staffs) > 0 ){ $result1 = $this->support_model->addStaff($staffs, $id, $data['user_id'], $result0); }
            if ( $result1 == false ){ return $this->response(['status' => 'error','id'=>$result1, 'message' => 'Saved Office and Equipment.']); }
            return $this->response(['status' => 'success','id' =>$result1, 'message' => 'Saved everything as successfully.']);
        }
    }

    public function getBusiness() {
        $data = $this->jsonInput();
        $input['created_by'] = $data['user_id'];
        $objs = $this->business_model->myBusiness($input);
        return $this->response(['status' => 'success', 'data' => $objs]);
    }

    public function getBranchs(){
        $data = $this->jsonInput();
        $objs = $this->support_model->mybranchs($data['user_id']);
        return $this->response(['status' => 'success', 'data' => $objs]);
    }

    public function addBstaffs(){
        $data = $this->jsonInput();
        $staffs = $data['staffs'];
        $offices = $data['offices'];
        $created_by = $data['user_id'];
        $num = $data['all'];
        $bstaffs = 0;
        for ($i = 0;$i<sizeof($offices);$i++){
            try {
                if ( sizeof($staffs[$i]) > 0 ){ 
                    $result = $this->support_model->addStaff($staffs[$i], (int)($offices[$i]['buzi_id']), $created_by, $offices[$i]['id']);
                    if ( $result == true ){ $bstaffs++; }
                }
            } catch (\Throwable $th) {
                return $this->response(['status' => 'success', 'data' => $th]);
            }
        }
        if ( $bstaffs == $num ){ return $this->response(['status' => 'success', 'data' => " Saved Branch staffs as successfully."]); }
        return $this->response(['status' => 'error', 'data' => "Please input correct data ."]);
    }

    public function getList(){
        $data             = $this->jsonInput();
        $blist = $this->business_model->getlist();
        $olist = $this->support_model->getlist();
        $value = $this->support_model->getId($data['user_id']);
        return $this->response(['status' => 'success', 'data' => [$blist, $olist, $value[0]]]);
    }

    public function saveId(){
        $data = $this->jsonInput();
        $result = $this->support_model->ids($data['buzi_id'], $data['office_id'], $data['user_id'] );
        if ($result){ return $this->response(['status' => 'success', 'data' => "Saved as successfully."]); }
    }

    public function getPendingBusiness() {
        $data = $this->jsonInput();
        $input['created_by'] = $data['user_id'];
        $objs = $this->business_model->getPendingByCreatedBy($input);
        return $this->response(['status' => 'success', 'data' => $objs]);
    }
//  ====================================================================================== Business End =========================

    public function getReport() {
        $data             = $this->jsonInput();
        $input['profess_name'] = $data['user_name'];
        $objs = $this->report_model->getReportByName($input);
        return $this->response(['status' => 'success', 'data' => $objs]);
    }

    function checkExist(){
        $realname = "";
        $data             = $this->jsonInput();
        $names = $this->db->select("name")->from('tbl_profile')->where('name', $data["key"])->get()->result();
        if (empty($names)){
            $names = $this->db->select("name")->from('tbl_profile')->where('reg_number', $data["key"])->get()->result();
            if (empty($names)){
                $names = $this->db->select("profess")->from('business')->where('org_name', $data["key"])->get()->result();   
                if (empty($names)){
                    return $this->response(['status' => 'success', 'data' =>"false",'profile'=>"false" ]);
                }
                else{
                    $realname = $names[0]->profess;
                }
            }
            else{
                $realname = $names[0]->name;
            }
        }
        else{
            $realname = $names[0]->name;
        }
        $created_by = $this->profile_model->getProfessId($realname);
        $detail_id['created_by'] = $created_by->created_by;
        $details = $this->project_model->getByCreatedBy($detail_id);
        return $this->response(['status' => 'success', 'data' =>$details,'profile'=>$created_by ]);        
    }

    function getVerifyCode(){
        $charset = "0123456789";
        $base = strlen($charset);
        $result = '';
        $now = explode(' ', microtime())[1];
        while ($now >= $base){
            $i = $now % $base;
            $result = $charset[$i] . $result;
            $now /= $base;
        }
        $verification_code = substr($result, -5);
        return $verification_code;
    }

    // public function getPdf() {
    //     $data             = $this->jsonInput();
    //     $input['created_by'] = $data['user_id'];
    //     $filename = $this->profile_model->getByCreatedBy($input);
    //     $destination = getcwd().'\\assets\\uploads\\'.Strval($filename['0']->file);
    //     // $destination = getcwd().'/assets/uploads/'.Strval($filename['0']->file);
    //     $result = $this->readPdf($destination);
    //     if ($result == false){
    //         return $this->response(['status' => 'success', 'file' => 'There is no existed your profile pdf file.Please submit again.']);    
    //     }
    //     return $this->response(['status' => 'success', 'file' => $result]);
    // }
    // public function readPdf($path)
    // {        
    //     $pdf = new PDF();
    //     $pdf->Open();
    //     $pdf = new PDFToText();
    //     foreach ($pdf -> Pages as $page_number => $page_contents) {
    //         $result = $result."Contents of page #$page_number :\n$page_contents\n";
    //     }
    //     $pdf = new PDF2Text();
    //     $pdf->setFilename($path);
    //     $pdf->decodePDF();
    // }

    public function getPay() {
        $query = $this->db->select("*")->from('tbl_pay')->get();
        $data = [];
        foreach ($query->result() as $row)
        {
            $data[] = $row;
        }        
        return $this->response(['status' => 'success', 'data' =>$data]);
    }

    public function getDetails(){
        $query = $this->db->select("*")->from('tbl_details')->get();
        $data = [];
        foreach ($query->result() as $row)
        {
            $data[] = $row;
        }        
        return $this->response(['status' => 'success', 'data' =>$data]);
    }
// additional part ---------------------------------------------------------------------------
    public function createPdf($detail)
    {
        try {
            require('fpdf.php'); $pdf = new FPDF('P','mm','A4'); $pdf->AddPage();
            $pdf->SetFont('Arial',null,20); $title = 'E-PLAN FILLING CONFIRMATION'; $pdf->SetXY(48, 20);  $pdf->Write(0, $title); $pdf->SetFont('Arial',null,15);
            $pdf->SetXY(21, 35); $pdf->Write(0, "This serves to confirm that the outlined project, whose details appear");
            $pdf->SetXY(18, 45); $pdf->Write(0, "below, has been duly filed in accordance with the provisions of the relevant");
            $pdf->SetXY(18, 55); $pdf->Write(0, "professional council with VeriProf.");
            $pdf->SetXY(26, 70); $pdf->Write(0, "1. Project Title  :  ".$detail['project_title']);
            $pdf->SetXY(26, 80); $pdf->Write(0, "2. ERF NO  :  ".$detail['erfno']);
            $pdf->SetXY(26, 90); $pdf->Write(0, "3. LOCATION  :  ".$detail['project_address_line_1']."  ".$detail['project_address_line_2']);
            $pdf->SetXY(55, 98); $pdf->Write(0, $detail['project_city'].'  '.$detail['project_province'].'  '.$detail['project_zipcode']);
            $pdf->SetXY(26, 108); $pdf->Write(0, "4. VeriProf PLAN NO  :  ".Strval($detail['id']));
            $pdf->SetXY(26, 118); $pdf->Write(0, "5. ESTIMATED COST  :  ".$detail['project_cost'].' R');
            $pdf->SetXY(26, 128); $pdf->Write(0, "6. RESPONSIBLE PROFESSIONAL  :  ".$detail['professional_name']);
            $pdf->SetXY(26, 138); $pdf->Write(0, "7. PR. REGISTRATION NO.  :  ".$detail['professional_reg_number']);
            $pdf->SetXY(26, 148); $pdf->Write(0, "8. EMAIL  :  ".$detail['contact_email']);
            $pdf->SetXY(26, 158); $pdf->Write(0, "9. TELEPHONE  :  ".$detail['contact_phone']);
            $savedName = time().'_'.$detail['project_title'].'.pdf';
            $path = getcwd().'\\assets\\certificate\\'.$savedName;
            // $path = getcwd().'/assets/certificate/'.$detail["filename"];
            $pdf->Output($path,"F");
            return $savedName;
        } catch (\Throwable $th) {
            return false;
        }        
    }

    public function sendEmail($emailaddress,$verified){
        try {
            $url = "https://api.sendgrid.com/v3/mail/send";
            $curl = curl_init($url);
            curl_setopt($curl, CURLOPT_URL, $url);
            $headers = array(
                "Authorization: Bearer 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",
                "Content-Type: application/json"
            );
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            $data = '{"personalizations": [{"to": [{"email": "'.$emailaddress.'" }]}],"from": {"email": "info@veriprof.co.za"},"subject": "Verification Email","content": [{"type": "text/plain", "value": "'.$verified.'"}]}';
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
            curl_exec($curl);
            curl_close($curl);
            return true;
        } catch (\Throwable $th) {
            return false;
        }
        
    }
}
?>