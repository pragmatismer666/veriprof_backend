<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

class Accessor extends CI_Controller
{

    private static $instance = null;

    function __construct()
    {
        parent::__construct();
        $this->load->model('project_model');
        $this->load->model('user_model');
        $this->load->model('business_model');
        $this->load->model('schedule_model');
        $this->load->model('login_model');
        $this->load->model('report_model');
        $this->load->model('profile_model');
        $this->load->model('support_model');
    }

    static public function getInstance() {

        if (self::$instance == null)
        {
            self::$instance = new Accessor();
        }
    
        return self::$instance;
    }

    public function response($data) {
        echo json_encode($data);
        return;
    }

    public function jsonInput() {
        $json = file_get_contents('php://input');
        return json_decode($json, true);
    }
   
    public function actionPendingPlan() {
        $data = $this->jsonInput();
        $objs = $this->user_model->verficationProf($data['user_id'], $data['verified']);
        return $this->response(['status' => 'success', 'data' => $objs]);
    }

    public function getUser() {
        $data = $this->jsonInput();
        $objs = $this->user_model->getUserInfo($data['user_id']);
        return $this->response(['status' => 'success', 'data' => $objs]);
    }
//  ------------------------------------------------------------------------------------------------ updated use function ------------------

    public function getVerifiedProf() {
        $objs = $this->user_model->getVerifiedProf();
        return $this->response(['status' => 'success', 'data' => $objs]);
    }

    public function getPendingProf() {
        $key = array('status'=>'Unverified');
        $objs = $this->profile_model->getProfile($key);
        for ($i=0;$i<sizeof($objs);$i++){
            $email = $this->db->select('email')->from('tbl_users')->where('userId', (int)($objs[$i]->user_id))->get()->result();
            $objs[$i]->email = $email[0]->email;
        }
        return $this->response(['status' => 'success', 'data' => $objs]);
    }

    public function getVerified() {
        $data = $this->jsonInput();
        $input = array('verified_by'=>$data['verified_by'], 'status'=>$data['status']);
        $verified_business = $this->business_model->getBusiness($input);
        $verified_profile = $this->profile_model->getProfile($input);
        return $this->response(['status' => 'success', 'data' => [sizeof($verified_business), sizeof($verified_profile)]]);
    }

    public function getBusiness() {
        $business = $this->business_model->getBusiness(array());
        $objs = [];
        for ( $i = 0;$i < sizeof($business); $i++){
            $key = array('buzi_id'=>(int)($business[$i]->id), 'status'=>'Unverified');
            $offices = $this->support_model->getOffices($key); 
            for ($j = 0; $j < sizeof($offices); $j++){
                $offices[$j]->pname = $business[$i]->pname;
                $offices[$j]->pcouncil = $business[$i]->pcouncil;
                $offices[$j]->pcipc_reg_no = $business[$i]->pcipc_reg_no;
                $offices[$j]->director = $business[$i]->director;
                $offices[$j]->dir_prof_regno = $business[$i]->dir_prof_regno;
                $offices[$j]->owned = $business[$i]->owned;
                $offices[$j]->ptype = $business[$i]->ptype;
                array_push($objs, $offices[$j]);
            }
        }
        return $this->response(['status' => 'success', 'data' => $objs]);
    }

    public function verifyBusiness() {
        $data = $this->jsonInput();
        $key = array('id'=>(int)($data['office_id']), 'buzi_id'=>(int)($data['business_id']));
        $update = array('verify_by'=>$data['user_id'], 'verify_at'=>date('Y-m-d h:i:s'), 'status'=>'Verified');
        $result = $this->support_model->updateOffices($key, $update);
        if ( $result ){ return $this->response(['status' => 'success', 'data' => 'Verified as successfully.']); }
        else { return $this->response(['status' => 'error', 'data' => 'Get problem in verify.']); }
    }

    public function verifyProf() {
        $data = $this->jsonInput();
        $key = array('id'=>(int)($data['profile_id']));
        $update = array('verified_by'=>$data['user_id'], 'verified_at'=>date('Y-m-d h:i:s'), 'status'=>'Verified');
        $result = $this->profile_model->updateProfile_accessor($key, $update);
        if ($result){ return $this->response(['status' => 'success', 'data' => 'Verified as successfully.']); }
        else { return $this->response(['status' => 'error', 'data' => 'Get problem in verify.']); }
    }

    public function getSchedule() {
        $result = $this->db->select('*')->from('tbl_schedule')->get()->result();
        $this->response(['status' => 'success', 'data' => $result]);
    }

    public function putSchedule() {
        $data = $this->jsonInput();
        $key = $data['data'];
        $key['created_by'] = $data['user_id'];
        $schedules = $this->schedule_model->addNew($key);
        return $this->response(['status' => 'success', 'data' => $schedules, 'message'=>'Shared as succesfully']);
    }
//  ------------------------------------------------------------------------------------------------ Business Part ------------------
    public function checkPassword(){
        $data = $this->jsonInput();
        $result = $this->login_model->getPassword($data['email']);
        if ($result == null){
            $message = 'This email is not yet registered with VerifProf. Please register and log in';
        }
        else{
            $message = 'Please check email, There will be new password.'; 
            $random_code = $this->getVerifyCode();
            $newPass['password'] = getHashedPassword($random_code);
            $this->login_model->updatePassword($data['email'],$newPass);
            $email_content = 'Verified, Your new passowrd is '.$random_code;
            $this->sendEmail($data['email'],$email_content);
        }
        return $this->response(['status' => 'success', 'result' => $result,'message' => $message]);
    }

    function getVerifyCode(){
        $charset = "ABCDEFGHIGKLMNOPQRSTUVWXYZ";
        $base = strlen($charset);
        $result = '';
        $now = explode(' ', microtime())[1];
        while ($now >= $base){
            $i = $now % $base;
            $result = $charset[$i] . $result;
            $now /= $base;
        }
        return substr($result, -7);
    }

    public function addReport(){
        $data             = $this->jsonInput();
        if ($data == null){ return null; }
        $input            = $data['data'];
        $input['created_at'] = date('Y-m-d h:i:s');        
        $input['filename'] = Strval(time())."_report.pdf";
        $this->createPDF($input);
        $id = $this->report_model->addNew($input);
        if($id == false) { 
            return $this->response(['status' => 'error', 'message' => 'Insert Error']);
        }
        $professEmail = $this->user_model->getProfessEmail($input["profess_name"]);
        $verified = "Hi ".$input["profess_name"].",  ".$input["accessor"]." is submitted report about ".$input["project_title"].".  You can check content by downloading report in your report tab.";
        $this->sendEmail($professEmail['0']->email,$verified);
        return $this->response(['status' => 'success', 'data' => $professEmail['0'], 'message' => 'Successfully Inserted']);
    }


    public function sendEmail($emailaddress,$verified){
        $url = "https://api.sendgrid.com/v3/mail/send";
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        $headers = array(
        "Authorization: Bearer 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",
        "Content-Type: application/json"
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        $data = '{"personalizations": [{"to": [{"email": "'.$emailaddress.'" }]}],"from": {"email": "info@veriprof.co.za"},"subject": "Verification Email","content": [{"type": "text/plain", "value": "'.$verified.'"}]}';
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_exec($curl);
        curl_close($curl);
        return true;
    }

    public function createPDF($detail)
    {
        require('fpdf.php');
        $pdf = new FPDF('P','mm','A4');
        $pdf->AddPage();
        $pdf->SetFont('Arial',null,19);
        $title = $detail["report_type"].' Report';
        $pdf->SetXY(63, 20); 
        $pdf->Write(0, $title);
        $pdf->SetFont('Arial',null,15);
        $intro = "Project Title : ".$detail["project_title"]."          Accessor : ".$detail["accessor"];
        $pdf->SetXY(20, 33); 
        $pdf->Write(0, $intro);
        $pdf->SetXY(20, 44); 
        $pdf->Write(0, "Reported Date : ".$detail["created_at"]);
        $pdf->SetXY(20, 55); 
        $pdf->Write(0, $detail["report_content"]);        
        // $path = getcwd().'\\assets\\reports\\'.$filename;
        $path = getcwd().'/assets/reports/'.$detail["filename"];
        $pdf->Output($path,"F");
    }
}
?>