<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

include_once(__DIR__.'/Professional.php');
include_once(__DIR__.'/Accessor.php');


class Api extends CI_Controller
{
    public function route($functionName) {
        $fn = $this->dashesToCamelCase($functionName);
        if(method_exists($this, $this->dashesToCamelCase($fn))) {
            $this->$fn();
        } else {
            return $this->response(['status' => 'error', 'message' => 'invaild endpoint hit']);
        }
    }

    public function routeController($className, $functionName) {
        $className = ucfirst($className);
        $obj = new $className;
        $fn = $this->dashesToCamelCase($functionName);
        return $obj->$fn($this->input->post());
    }

    function dashesToCamelCase($string, $capitalizeFirstCharacter = false) 
    {
        $str = str_replace(' ', '', ucwords(str_replace('-', ' ', $string)));
        if (!$capitalizeFirstCharacter) {
            $str[0] = strtolower($str[0]);
        }
        return $str;
    }

    function response($data) {
        echo json_encode($data);
        return;
    }

    function jsonInput() {
        $json = file_get_contents('php://input');
        return json_decode($json, true);
    }

    public function login() {
        $this->load->model('login_model');
        $data = $this->jsonInput();
        extract($data);
        if(!isset($email) || !isset($password)) { return $this->response(['status' => 'error', 'message' => 'Invaild Information']); }
        $email = strtolower($this->security->xss_clean($email));
        $user = $this->login_model->loginMe($email, $password, $role);
        if($user == []) { return $this->response(['status' => 'error', 'message' => 'Invaild Information']); }
        return $this->response(['status' => 'success', 'message' => 'Login Successfully', 'data' => $user]);
    }

    public function register() {
        $this->load->model('login_model');
        $data = $this->jsonInput();
        extract($data);
        if(!isset($email) || !isset($password) || !isset($role)) {
            return $this->response(['status' => 'error', 'message' => 'Invaild Information']);
        }
        $email = strtolower($this->security->xss_clean($email));    
        $user = $this->login_model->registerMe($first_name,$last_name,$email,$password, $role);
        $verified = "Hi ".$first_name." ".$last_name.", You are signed up in Veriprof ".$role."successfully.";
        $this->sendEmail($email,$verified);
        return $this->response($user);
    }
    
    public function uploadFile() {
        $filename = $_FILES['file-to-upload']['tmp_name'];
        $savedName = time().'_'.$_FILES['file-to-upload']['name'];
        $destination = getcwd().'\\assets\\uploads\\'.$savedName;
        move_uploaded_file($filename, $destination);
        return $this->response(['status' => 'success', 'filename' => $savedName]);
    }
    
    public function sendEmail($emailaddress,$verified){
        $url = "https://api.sendgrid.com/v3/mail/send";
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_URL, $url);
        $headers = array(
        "Authorization: Bearer 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",
        "Content-Type: application/json"
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
        $data = '{"personalizations": [{"to": [{"email": "'.$emailaddress.'" }]}],"from": {"email": "info@veriprof.co.za"},"subject": "Verification Email","content": [{"type": "text/plain", "value": "'.$verified.'"}]}';
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_exec($curl);
        curl_close($curl);
        return true;
    }
}

?>