<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : User_model (User Model)
 * User model class to get to handle user related data 
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Report_model extends CI_Model
{

    function addNew($data)
    {    
        $sql = $this->db->set($data)->get_compiled_insert('tbl_reports');
        $res = $this->db->simple_query($sql);
        if($res) {
            $insert_id = $this->db->insert_id(); 
            return $insert_id;
        } 
        
        return false;
    }

    function getReportByName($basedata) {
        
        $query = $this->db->select("*")->from('tbl_reports')->where('profess_name', $basedata["profess_name"])->get();
        $data = [];
        foreach ($query->result() as $row)
        {
            $data[] = $row;
        }
        return $data;
    }
}

  