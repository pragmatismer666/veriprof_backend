<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : User_model (User Model)
 * User model class to get to handle user related data 
 * @author : Kishor Mali
 * @version : 1.1
 * @since : 15 November 2016
 */
class Project_model extends CI_Model
{

    function addNew($data)
    {    
        $query = $this->db->select("*")->from('tbl_projects')->where(array('title'=>$data['title'],'type'=>$data['type']))->order_by('id', 'desc')->get();
        if (sizeof($query->result()) > 0){ return "exist";}
        $sql = $this->db->set($data)->get_compiled_insert('tbl_projects');
        $res = $this->db->simple_query($sql);
        if( $res) { return $this->db->insert_id();} 
        return false;
    }

    function getByCreatedBy($data) {
        $query = $this->db->select("*")->from('tbl_projects')->where('created_by', $data['created_by'])->order_by('id', 'desc')->get();
        $data = [];
        foreach ($query->result() as $row)
        {
            $data[] = $row;
        }        
        return $data;
    }
        
    function changeProjectStatus($title, $user_id, $verified) {
        $this->db->where('created_by', $user_id);
        $this->db->where('title', $title);
        $this->db->update('tbl_projects', ['status' => $verified, 'completed_at'=>date('Y-m-d h:i:s')]);        
        return $this->db->affected_rows();
    }
}

  